littleDragon
============

concentrately，delegently