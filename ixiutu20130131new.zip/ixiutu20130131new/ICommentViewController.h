//
//  ICommentViewController.h
//  IXiuTu
//
//  Created by vbarter on 13-1-27.
//  Copyright (c) 2013年 shixiaolong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICommentViewController : UIViewController

@end
