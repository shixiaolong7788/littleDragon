//
//  UIButton+Additions.m
//  AppTemplate
//
//  Created by 欧然 Wu on 12-3-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UIButton+Additions.h"

@implementation UIButton(UIButton_Additions)

@end
