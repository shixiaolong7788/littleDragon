//
//  GHPushedViewController.h
//  GHSidebarNav
//
//  Created by Greg Haines on 11/29/11.
//

#import <Foundation/Foundation.h>

@interface GHPushedViewController : UIViewController

- (id)initWithTitle:(NSString *)title;

@end
